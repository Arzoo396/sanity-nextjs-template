import { SchemaTypeDefinition } from 'sanity'

import blockContent from './blockContent'
import post from './post'
import page from './page'
import heroSection from './heroSection'
import pageSection from './pageSection'
import cardCollection from './cardCollection'


export const schemaTypes = [post, blockContent, page]
export const schema: { types: SchemaTypeDefinition[] } = {
  types: [post, blockContent, page, heroSection, pageSection, cardCollection],
}
