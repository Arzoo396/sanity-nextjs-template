export interface ImageAsset {
  url: string
  alt?: string
  // Add more fields as needed
}
