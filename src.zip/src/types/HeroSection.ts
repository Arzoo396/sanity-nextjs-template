import { ImageAsset } from 'sanity'

export interface HeroSection {
  heroImage?: ImageAsset
  heroText?: string
  // Add more fields as needed for your hero section
}
