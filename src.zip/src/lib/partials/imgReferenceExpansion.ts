export const imgReferenceExpansion = `{
  "url": url,
  // Add other fields if needed
}`

export default imgReferenceExpansion
